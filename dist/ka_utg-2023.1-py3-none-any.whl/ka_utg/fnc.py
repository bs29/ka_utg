# coding=utf-8

# from .log import Log

# from typing import NewType
# from typing import Dict, List, Union

# Value = NewType('Value', Union[str, List, Dict])


class Fnc:
    """
    Functions
    """
    @staticmethod
    def identity(obj):
        return obj
